from .test_MySQLdb_nonstandard import *

if __name__ == "__main__":
    import unittest

    unittest.main()
