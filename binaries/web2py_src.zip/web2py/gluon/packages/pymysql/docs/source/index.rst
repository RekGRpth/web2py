PyMySQL documentation
=====================

.. toctree::
  :maxdepth: 2

  user/index
  modules/index


Indices and tables
==================

* :ref:`genindex`
* :ref:`modindex`
* :ref:`search`

